fp_func3_wrapper parameters: 8, 0.530000, 9
fp_func3 parameters: 8, 0.530000, 9
fp_func3 result 17

fp_func4_wrapper parameters: 3.333333e-01, 0.450000, 5, 2.378788e+01
fp_func4 parameters: 3.333333e-01, 0.450000, 5, 2.378788e+01
fp_func4_wrapper result: 0.550000
fp_func4 result 0.550000

fp_func1_wrapper parameters: 3.333333e-01
fp_func1_wrapper result: 4.333333e-01
fp_func1 result 4.333333e-01

